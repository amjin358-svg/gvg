/** @gvg/kernel/plugin/PluginManifest */

export type RouteDefinition = {
  path: string;
  component: string;
  title?: string;
  auth?: boolean;
};

/** @deprecated use RouteDefinition */
export type PluginRoute = RouteDefinition;

export type NavigationItem = {
  label: string;
  href: string;
  roles?: string[];
  icon?: string;
};

/** @deprecated use NavigationItem */
export type PluginNavItem = NavigationItem;

export type PermissionDefinition = {
  key: string;
  description?: string;
};

export type PluginManifest = {
  id: string;
  name: string;
  nameZh?: string;
  version: string;
  description?: string;
  dependencies?: string[];
  tags?: string[];
};

export function isValidManifest(
  manifest: PluginManifest | null | undefined,
): manifest is PluginManifest {
  return Boolean(manifest?.id && manifest.version && manifest.name);
}
