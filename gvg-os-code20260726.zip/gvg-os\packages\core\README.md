﻿# @gvg/core

```
packages/core/
├── auth/
├── tenant/
├── workspace/
├── navigation/
├── permission/
├── featureFlag/
├── audit/
└── notification/
```

```ts
import {
  login,
  selectWorkspace,
  isModuleEnabled,
  recordAudit,
  sendNotification,
} from "@gvg/core";
```
