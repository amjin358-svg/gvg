/**
 * Plugin boot pipeline
 *
 * ```
 * Start
 *   │
 *   ▼
 * Scan plugins/
 *   │
 *   ▼
 * Load Manifest
 *   │
 *   ▼
 * Register Navigation
 *   │
 *   ▼
 * Register Routes
 *   │
 *   ▼
 * Register Permissions
 *   │
 *   ▼
 * Boot Plugin
 * ```
 *
 * Usage:
 *
 * ```ts
 * import { bootGVGPlugins } from "@gvg/plugins/boot";
 *
 * const { report, host } = await bootGVGPlugins();
 * host.navigation();
 * host.routes();
 * host.permissions();
 * ```
 */

export {};
