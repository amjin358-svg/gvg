﻿# @gvg/plugin-marketplace

```
plugins/marketplace/
├── manifest.ts
├── index.ts
├── routes.ts
├── permissions.ts
├── navigation.ts
├── product/
├── supplier/
├── rfq/
└── procurement/
```

```
Marketplace
├── Product        → product/
├── Category       → product/
├── Brand          → product/
├── Supplier       → supplier/
├── RFQ            → rfq/
├── Procurement    → procurement/
├── Favorite       → product/
└── AI Search      → product/
```

```ts
import marketplace, { product, supplier, rfq, procurement } from "@gvg/plugin-marketplace";
```
