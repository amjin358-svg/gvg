﻿/** Trade services */

export async function getOverview() {
  return {
    plugin: "trade",
    title: "國際貿易",
    status: "ready" as const,
  };
}
