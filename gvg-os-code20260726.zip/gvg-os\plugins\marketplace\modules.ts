/**
 * Marketplace module tree
 *
 * Marketplace
 * ├── Product
 * ├── Category
 * ├── Brand
 * ├── Supplier
 * ├── RFQ
 * ├── Procurement
 * ├── Favorite
 * └── AI Search
 */

export type MarketplaceModuleId =
  | "product"
  | "category"
  | "brand"
  | "supplier"
  | "rfq"
  | "procurement"
  | "favorite"
  | "ai-search";

export type MarketplaceModule = {
  id: MarketplaceModuleId;
  label: string;
  labelZh: string;
  href: string;
  description: string;
};

export const MARKETPLACE_MODULES: MarketplaceModule[] = [
  {
    id: "product",
    label: "Product",
    labelZh: "產品",
    href: "/marketplace/products",
    description: "Catalog products and SKUs",
  },
  {
    id: "category",
    label: "Category",
    labelZh: "分類",
    href: "/marketplace/categories",
    description: "Product categories and taxonomy",
  },
  {
    id: "brand",
    label: "Brand",
    labelZh: "品牌",
    href: "/marketplace/brands",
    description: "Brand directory",
  },
  {
    id: "supplier",
    label: "Supplier",
    labelZh: "供應商",
    href: "/marketplace/suppliers",
    description: "Supplier profiles and capabilities",
  },
  {
    id: "rfq",
    label: "RFQ",
    labelZh: "詢價",
    href: "/marketplace/rfq",
    description: "Request for quotation workflows",
  },
  {
    id: "procurement",
    label: "Procurement",
    labelZh: "採購",
    href: "/marketplace/procurement",
    description: "Sourcing and procurement desk",
  },
  {
    id: "favorite",
    label: "Favorite",
    labelZh: "收藏",
    href: "/marketplace/favorites",
    description: "Saved products and suppliers",
  },
  {
    id: "ai-search",
    label: "AI Search",
    labelZh: "AI 搜尋",
    href: "/marketplace/ai-search",
    description: "Intelligent catalog search",
  },
];

export function getMarketplaceModule(
  id: MarketplaceModuleId,
): MarketplaceModule | undefined {
  return MARKETPLACE_MODULES.find((m) => m.id === id);
}

export default MARKETPLACE_MODULES;
