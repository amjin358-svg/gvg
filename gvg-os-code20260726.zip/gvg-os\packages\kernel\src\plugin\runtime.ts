/** Compat re-exports for @gvg/kernel/plugin/runtime */
export {
  createPluginRuntime,
  registerPluginNavigation,
  registerPluginRoutes,
  registerPluginPermissions,
  registerPluginWidgets,
  getAllNavigation,
  getAllRoutes,
  getAllPermissions,
  getAllWidgets,
  clearPluginRuntime,
  PluginRegistry,
} from "./PluginRegistry";
export type { PluginRuntimeState, RegistryEntry } from "./PluginRegistry";

