import {
  definePlugin,
  defineRoute,
  definePermission,
  defineNavigation,
  defineDashboardWidget,
} from "@gvg/sdk";
import { manifest } from "./manifest";
import { routes } from "./routes";
import { permissions } from "./permissions";
import { navigationFlat } from "./navigation";

export { manifest } from "./manifest";
export { routes } from "./routes";
export { permissions } from "./permissions";
export { navigation, navigationFlat } from "./navigation";
export { default as menu } from "./menu";
export {
  MARKETPLACE_MODULES,
  getMarketplaceModule,
} from "./modules";
export type { MarketplaceModule, MarketplaceModuleId } from "./modules";

export * as product from "./product";
export * as supplier from "./supplier";
export * as rfq from "./rfq";
export * as procurement from "./procurement";

export * from "./services";
export * from "./repositories";
export * from "./components";
export * from "./pages";

/** @gvg/plugin-marketplace */
export const plugin = definePlugin({
  manifest,
  routes: routes.map((r) =>
    defineRoute({
      path: r.path,
      component: r.page,
      title: r.title,
      auth: r.auth,
    }),
  ),
  navigation: navigationFlat.map((item) =>
    defineNavigation({
      label: item.label,
      href: item.href,
      roles: item.roles,
    }),
  ),
  permissions: permissions.map((key) => definePermission(key)),
  widgets: [
    defineDashboardWidget({
      id: "marketplace.catalog-health",
      title: "Catalog Health",
      description: "Products, brands, and categories at a glance",
      component: "product/widgets/CatalogHealth",
      size: "md",
      order: 10,
    }),
    defineDashboardWidget({
      id: "marketplace.open-rfqs",
      title: "Open RFQs",
      description: "Active marketplace RFQ pipeline",
      component: "rfq/widgets/OpenRfqs",
      size: "sm",
      order: 20,
    }),
  ],
  register(app) {
    app.logger?.info("marketplace registered");
  },
});

export default plugin;
