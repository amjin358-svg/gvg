import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { manifest } from "../manifest";
import { searchProducts } from "../services";
import { permissions, canMarketplace } from "../permissions";
import { MARKETPLACE_MODULES } from "../modules";
import { routes } from "../routes";

describe("marketplace plugin", () => {
  it("exposes manifest id", () => {
    assert.equal(manifest.id, "marketplace");
  });

  it("defines marketplace module tree", () => {
    assert.deepEqual(
      MARKETPLACE_MODULES.map((m) => m.label),
      [
        "Product",
        "Category",
        "Brand",
        "Supplier",
        "RFQ",
        "Procurement",
        "Favorite",
        "AI Search",
      ],
    );
  });

  it("registers routes for each module", () => {
    for (const m of MARKETPLACE_MODULES) {
      assert.ok(
        routes.some((r) => r.path === m.href),
        `missing route for ${m.id}`,
      );
    }
  });

  it("declares marketplace permissions", () => {
    assert.ok(permissions.includes("products.read"));
    assert.ok(permissions.includes("supplier.manage"));
    assert.ok(permissions.includes("rfq.create"));
    assert.ok(permissions.includes("ai.search"));
  });

  it("grants rfq.create to customers", () => {
    assert.equal(canMarketplace("customer", "rfq.create"), true);
    assert.equal(canMarketplace("guest", "rfq.create"), false);
  });

  it("searches catalog", async () => {
    const hits = await searchProducts("omega");
    assert.ok(hits.length >= 1);
  });
});
