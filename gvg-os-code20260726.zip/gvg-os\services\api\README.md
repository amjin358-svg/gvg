﻿# @gvg/api

GVG OS **api** service.
