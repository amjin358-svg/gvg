﻿import { createGVGPlugin } from "@gvg/sdk";
import { manifest } from "./manifest";
import { routes } from "./routes";
import { permissions } from "./permissions";
import { navigationFlat } from "./navigation";

export { manifest } from "./manifest";
export { routes } from "./routes";
export { permissions, canTrade } from "./permissions";
export { navigation, navigationFlat } from "./navigation";
export { TRADE_MODULES, getTradeModule } from "./modules";
export type { TradeModule, TradeModuleId } from "./modules";
export * from "./services";
export * from "./repositories";
export * from "./components";
export * from "./pages";

/** @gvg/plugin-trade */
export const plugin = createGVGPlugin({
  manifest,
  routes: routes.map((r) => ({
    path: r.path,
    component: r.page,
    title: r.title,
    auth: r.auth,
  })),
  navigation: navigationFlat,
  permissions: [...permissions],
});

export default plugin;
