/** @gvg/kernel/plugin — public barrel */

export {
  createGVGPlugin,
  createDefaultAppContext,
} from "./PluginContext";
export type {
  AppContext,
  PluginContext,
  GVGPlugin,
  GvgPlugin,
  CreateGVGPluginInput,
} from "./PluginContext";

export {
  definePlugin,
  defineRoute,
  definePermission,
  defineNavigation,
  defineDashboardWidget,
  defineManifest,
} from "./define";
export type {
  DashboardWidget,
  DashboardWidgetSize,
  DefinePluginInput,
  GVGPluginWithWidgets,
} from "./define";

export {
  isValidManifest,
} from "./PluginManifest";
export type {
  PluginManifest,
  RouteDefinition,
  NavigationItem,
  PermissionDefinition,
  PluginRoute,
  PluginNavItem,
} from "./PluginManifest";

export {
  PluginRegistry,
  createPluginRuntime,
  registerPluginNavigation,
  registerPluginRoutes,
  registerPluginPermissions,
  registerPluginWidgets,
  getAllNavigation,
  getAllRoutes,
  getAllPermissions,
  getAllWidgets,
  clearPluginRuntime,
  register,
  unregister,
  resolve,
  list,
  clearRegistry,
} from "./PluginRegistry";
export type {
  PluginRuntimeState,
  RegistryEntry,
} from "./PluginRegistry";

export {
  PluginLoader,
  PluginHost,
  createPluginLoader,
  createPluginHost,
  scanPlugins,
  bootPlugin,
  startPluginHost,
  loadPlugin,
  shutdownPlugin,
  unloadPlugin,
  getPlugin,
  listPlugins,
  clearPlugins,
} from "./PluginLoader";
export type {
  BootStage,
  PluginBootRecord,
  BootReport,
  PluginHostOptions,
} from "./PluginLoader";
