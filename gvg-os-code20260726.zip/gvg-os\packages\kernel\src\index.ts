/**
 * @gvg/kernel — GVG OS kernel
 *
 * packages/kernel/src/
 * ├── application/   Application · Bootstrap · Lifecycle
 * ├── plugin/        PluginLoader · PluginRegistry · PluginContext · PluginManifest
 * ├── event/         EventBus · EventEmitter · Events
 * ├── config/        Config · Environment
 * ├── logger/        Logger
 * └── errors/        BaseError · PluginError
 */

export {
  Application,
  createApp,
  Bootstrap,
  Lifecycle,
} from "./application";
export type {
  ApplicationOptions,
  KernelApp,
  KernelAppOptions,
  BootstrapOptions,
  BootstrapResult,
  LifecycleState,
} from "./application";

export {
  definePlugin,
  defineRoute,
  definePermission,
  defineNavigation,
  defineDashboardWidget,
  defineManifest,
  createGVGPlugin,
  loadPlugin,
  shutdownPlugin,
  unloadPlugin,
  getPlugin,
  listPlugins,
  clearPlugins,
  scanPlugins,
  bootPlugin,
  startPluginHost,
  createPluginHost,
  createPluginLoader,
  PluginHost,
  PluginLoader,
  PluginRegistry,
  createPluginRuntime,
  registerPluginNavigation,
  registerPluginRoutes,
  registerPluginPermissions,
  registerPluginWidgets,
  getAllNavigation,
  getAllRoutes,
  getAllPermissions,
  getAllWidgets,
  clearPluginRuntime,
  register,
  unregister,
  resolve,
  list,
  clearRegistry,
} from "./plugin";
export type {
  GVGPlugin,
  GvgPlugin,
  GVGPluginWithWidgets,
  AppContext,
  PluginContext,
  PluginManifest,
  RouteDefinition,
  NavigationItem,
  PermissionDefinition,
  PluginRoute,
  PluginNavItem,
  DashboardWidget,
  DashboardWidgetSize,
  DefinePluginInput,
  CreateGVGPluginInput,
  BootStage,
  PluginBootRecord,
  BootReport,
  PluginHostOptions,
  PluginRuntimeState,
  RegistryEntry,
} from "./plugin";

export {
  EventBus,
  eventBus,
  EventEmitter,
  createDomainEvent,
  on,
  off,
  emit,
  clearEventHandlers,
} from "./event";
export type { DomainEvent, DomainEventType, EventHandler } from "./event";

export {
  Config,
  getConfig,
  setConfig,
  resetConfig,
  resolveEnvironment,
  isProduction,
} from "./config";
export type { GvgConfig, GvgEnv } from "./config";

export {
  createLogger,
  logger,
  setLogLevel,
  LoggerService,
} from "./logger";
export type { Logger, LogLevel, LogContext } from "./logger";

export {
  BaseError,
  isBaseError,
  PluginError,
  isPluginError,
} from "./errors";
export type { ErrorCode } from "./errors";

export const name = "@gvg/kernel";
export const version = "0.1.0";
