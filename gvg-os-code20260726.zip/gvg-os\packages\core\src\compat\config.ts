/** Compat: @gvg/core/config → @gvg/kernel/config */
export * from "@gvg/kernel/config";
