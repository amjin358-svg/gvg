/** Compat re-exports for @gvg/kernel/plugin/host */
export {
  scanPlugins,
  bootPlugin,
  startPluginHost,
  createPluginHost,
  PluginHost,
  PluginLoader,
  createPluginLoader,
} from "./PluginLoader";
export type {
  BootStage,
  PluginBootRecord,
  BootReport,
  PluginHostOptions,
} from "./PluginLoader";
