/**
 * Boot GVG OS plugins
 *
 * Start
 *   → Scan plugins/
 *   → Load Manifest
 *   → Register Navigation
 *   → Register Routes
 *   → Register Permissions
 *   → Boot Plugin
 *
 * Module flags gate which plugins boot (e.g. warehouse/investment off).
 */

import {
  createPluginHost,
  type BootReport,
  type PluginHost,
  type PluginHostOptions,
} from "@gvg/kernel/plugin";
import { isModuleEnabled, listDisabledModules } from "@gvg/core/featureFlag";
import { PLUGIN_CATALOG } from "./catalog";

export async function bootGVGPlugins(
  options: PluginHostOptions = {},
): Promise<{ report: BootReport; host: PluginHost }> {
  const disabled = listDisabledModules();
  const exclude = [...(options.exclude ?? []), ...disabled];

  const catalog = PLUGIN_CATALOG.filter((p) => isModuleEnabled(p.id));
  const host = createPluginHost(catalog);

  const report = await host.start({
    ...options,
    exclude,
    onStage(stage, detail) {
      options.onStage?.(stage, detail);

      switch (stage) {
        case "start":
          console.info("[gvg] start");
          if (disabled.length) {
            console.info(`[gvg] module flags off → ${disabled.join(", ")}`);
          }
          break;
        case "scan":
          console.info(`[gvg] scan plugins/ → ${detail?.count ?? 0} candidates`);
          break;
        case "load_manifest":
          console.info(`[gvg] load manifest → ${detail?.id}@${detail?.version}`);
          break;
        case "register_navigation":
          console.info(`[gvg] register navigation → ${detail?.id}`);
          break;
        case "register_routes":
          console.info(`[gvg] register routes → ${detail?.id}`);
          break;
        case "register_permissions":
          console.info(`[gvg] register permissions → ${detail?.id}`);
          break;
        case "boot_plugin":
          console.info(`[gvg] boot plugin → ${detail?.id}`);
          break;
        case "ready":
          console.info(
            `[gvg] ready → booted=${detail?.booted ?? 0} failed=${detail?.failed ?? 0}`,
          );
          break;
        case "error":
          console.error("[gvg] plugin host error", detail);
          break;
      }
    },
  });

  return { report, host };
}

export { createPluginHost, PLUGIN_CATALOG };
