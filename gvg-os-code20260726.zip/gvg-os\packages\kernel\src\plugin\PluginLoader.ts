/**
 * @gvg/kernel/plugin/PluginLoader
 *
 * Start → Scan → Load Manifest → Register Navigation
 *       → Register Routes → Register Permissions → Boot Plugin
 */

import { PluginError } from "../errors/PluginError";
import {
  createDefaultAppContext,
  type AppContext,
  type GVGPlugin,
} from "./PluginContext";
import { isValidManifest, type PluginManifest } from "./PluginManifest";
import {
  clearPluginRuntime,
  createPluginRuntime,
  getAllNavigation,
  getAllPermissions,
  getAllRoutes,
  PluginRegistry,
  registerPluginNavigation,
  registerPluginPermissions,
  registerPluginRoutes,
  registerPluginWidgets,
  type PluginRuntimeState,
} from "./PluginRegistry";

export type BootStage =
  | "start"
  | "scan"
  | "load_manifest"
  | "register_navigation"
  | "register_routes"
  | "register_permissions"
  | "register_widgets"
  | "boot_plugin"
  | "ready"
  | "error";

export type PluginBootRecord = {
  pluginId: string;
  manifest: PluginManifest;
  stage: BootStage;
  error?: string;
};

export type BootReport = {
  stage: BootStage;
  scanned: string[];
  booted: PluginBootRecord[];
  failed: PluginBootRecord[];
  runtime: PluginRuntimeState;
};

export type PluginHostOptions = {
  app?: Partial<AppContext>;
  exclude?: string[];
  include?: string[];
  onStage?: (stage: BootStage, detail?: Record<string, unknown>) => void;
};

function filterPlugins(
  plugins: GVGPlugin[],
  options: PluginHostOptions,
): GVGPlugin[] {
  let list = plugins;
  if (options.include?.length) {
    const allow = new Set(options.include);
    list = list.filter((p) => allow.has(p.id));
  }
  if (options.exclude?.length) {
    const deny = new Set(options.exclude);
    list = list.filter((p) => !deny.has(p.id));
  }
  return list;
}

export function scanPlugins(plugins: GVGPlugin[]): GVGPlugin[] {
  const seen = new Set<string>();
  const scanned: GVGPlugin[] = [];

  for (const plugin of plugins) {
    if (!plugin?.id || !plugin.manifest) continue;
    if (seen.has(plugin.id)) {
      throw new PluginError(`Duplicate plugin id during scan: ${plugin.id}`, {
        pluginId: plugin.id,
        stage: "scan",
      });
    }
    seen.add(plugin.id);
    scanned.push(plugin);
  }

  return scanned;
}

export async function bootPlugin(
  plugin: GVGPlugin,
  runtime: PluginRuntimeState,
  app: AppContext,
  onStage?: PluginHostOptions["onStage"],
): Promise<PluginBootRecord> {
  const record: PluginBootRecord = {
    pluginId: plugin.id,
    manifest: plugin.manifest,
    stage: "load_manifest",
  };

  try {
    onStage?.("load_manifest", { id: plugin.id, version: plugin.version });
    if (!isValidManifest(plugin.manifest)) {
      throw new PluginError(`Invalid manifest for plugin ${plugin.id}`, {
        pluginId: plugin.id,
        stage: "load_manifest",
      });
    }

    onStage?.("register_navigation", { id: plugin.id });
    record.stage = "register_navigation";
    registerPluginNavigation(runtime, plugin.id, plugin.navigation());

    onStage?.("register_routes", { id: plugin.id });
    record.stage = "register_routes";
    registerPluginRoutes(runtime, plugin.id, plugin.routes());

    onStage?.("register_permissions", { id: plugin.id });
    record.stage = "register_permissions";
    registerPluginPermissions(runtime, plugin.id, plugin.permissions());

    onStage?.("register_widgets", { id: plugin.id });
    record.stage = "register_widgets";
    registerPluginWidgets(runtime, plugin.id, plugin.widgets?.() ?? []);

    onStage?.("boot_plugin", { id: plugin.id });
    record.stage = "boot_plugin";
    await plugin.onInstall?.();
    plugin.register(app);
    await plugin.onBoot?.();

    record.stage = "ready";
    return record;
  } catch (err) {
    record.stage = "error";
    record.error = err instanceof Error ? err.message : String(err);
    return record;
  }
}

export async function startPluginHost(
  plugins: GVGPlugin[],
  options: PluginHostOptions = {},
): Promise<BootReport> {
  const onStage = options.onStage;
  onStage?.("start");

  const runtime = createPluginRuntime();
  const app = createDefaultAppContext(options.app);

  onStage?.("scan", { count: plugins.length });
  const scanned = filterPlugins(scanPlugins(plugins), options);

  const booted: PluginBootRecord[] = [];
  const failed: PluginBootRecord[] = [];

  for (const plugin of scanned) {
    const record = await bootPlugin(plugin, runtime, app, onStage);
    if (record.stage === "ready") booted.push(record);
    else failed.push(record);
  }

  const stage: BootStage = failed.length && !booted.length ? "error" : "ready";
  onStage?.(stage, { booted: booted.length, failed: failed.length });

  return {
    stage,
    scanned: scanned.map((p) => p.id),
    booted,
    failed,
    runtime,
  };
}

export class PluginLoader {
  private readonly registry = new PluginRegistry();
  private report: BootReport | null = null;

  catalog(plugins: GVGPlugin[]): this {
    for (const p of scanPlugins(plugins)) {
      if (!this.registry.get(p.id)) this.registry.add(p);
    }
    return this;
  }

  async start(options: PluginHostOptions = {}): Promise<BootReport> {
    this.registry.clearRuntime();
    this.report = await startPluginHost(this.registry.list(), options);
    this.registry.setRuntime(this.report.runtime);
    return this.report;
  }

  getReport(): BootReport | null {
    return this.report;
  }

  getRuntime(): PluginRuntimeState {
    return this.registry.getRuntime();
  }

  navigation() {
    return this.registry.navigation();
  }

  routes() {
    return this.registry.routes();
  }

  permissions() {
    return this.registry.permissions();
  }

  widgets() {
    return this.registry.widgets();
  }

  get(id: string): GVGPlugin | undefined {
    return this.registry.get(id);
  }

  list(): GVGPlugin[] {
    return this.registry.list();
  }

  async shutdown(): Promise<void> {
    for (const plugin of this.registry.list()) {
      await plugin.onShutdown?.();
    }
    this.registry.clearRuntime();
    this.report = null;
  }
}

/** @deprecated alias — prefer PluginLoader */
export class PluginHost extends PluginLoader {}

export function createPluginHost(plugins: GVGPlugin[] = []): PluginHost {
  return new PluginHost().catalog(plugins);
}

export function createPluginLoader(plugins: GVGPlugin[] = []): PluginLoader {
  return new PluginLoader().catalog(plugins);
}

const loaded = new Map<string, GVGPlugin>();
const defaultHost = createPluginHost();

export async function loadPlugin(
  plugin: GVGPlugin,
  app: AppContext,
): Promise<void> {
  if (loaded.has(plugin.id)) {
    throw new PluginError(`Plugin already loaded: ${plugin.id}`, {
      pluginId: plugin.id,
      stage: "boot_plugin",
    });
  }

  const runtime = createPluginRuntime();
  const record = await bootPlugin(plugin, runtime, app);
  if (record.stage !== "ready") {
    throw new PluginError(
      `Failed to boot plugin ${plugin.id}: ${record.error ?? record.stage}`,
      { pluginId: plugin.id, stage: record.stage },
    );
  }

  loaded.set(plugin.id, plugin);
  defaultHost.catalog([plugin]);
}

export async function shutdownPlugin(id: string): Promise<boolean> {
  const plugin = loaded.get(id);
  if (!plugin) return false;
  await plugin.onShutdown?.();
  return loaded.delete(id);
}

export function unloadPlugin(id: string): boolean {
  return loaded.delete(id);
}

export function getPlugin(id: string): GVGPlugin | undefined {
  return loaded.get(id);
}

export function listPlugins(): GVGPlugin[] {
  return Array.from(loaded.values());
}

export function clearPlugins(): void {
  loaded.clear();
  clearPluginRuntime(createPluginRuntime());
}
