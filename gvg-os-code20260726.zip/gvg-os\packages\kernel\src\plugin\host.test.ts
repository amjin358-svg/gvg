/**
 * Minimal host pipeline smoke test
 */

import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  createGVGPlugin,
  createPluginHost,
  scanPlugins,
} from "./index";

describe("plugin boot pipeline", () => {
  it("scans → manifests → registers → boots", async () => {
    const stages: string[] = [];

    const alpha = createGVGPlugin({
      manifest: {
        id: "alpha",
        name: "Alpha",
        version: "1.0.0",
      },
      routes: [{ path: "/alpha", component: "AlphaPage" }],
      navigation: [{ label: "Alpha", href: "/alpha" }],
      permissions: ["alpha.read"],
    });

    const beta = createGVGPlugin({
      manifest: {
        id: "beta",
        name: "Beta",
        version: "1.0.0",
      },
      routes: [{ path: "/beta", component: "BetaPage" }],
      navigation: [{ label: "Beta", href: "/beta" }],
      permissions: ["beta.write"],
    });

    const scanned = scanPlugins([alpha, beta]);
    assert.equal(scanned.length, 2);

    const host = createPluginHost(scanned);
    const report = await host.start({
      onStage(stage) {
        stages.push(stage);
      },
    });

    assert.equal(report.stage, "ready");
    assert.deepEqual(report.scanned, ["alpha", "beta"]);
    assert.equal(report.booted.length, 2);
    assert.equal(report.failed.length, 0);

    assert.equal(host.navigation().length, 2);
    assert.equal(host.routes().length, 2);
    assert.equal(host.permissions().length, 2);

    assert.ok(stages.includes("start"));
    assert.ok(stages.includes("scan"));
    assert.ok(stages.includes("load_manifest"));
    assert.ok(stages.includes("register_navigation"));
    assert.ok(stages.includes("register_routes"));
    assert.ok(stages.includes("register_permissions"));
    assert.ok(stages.includes("boot_plugin"));
    assert.ok(stages.includes("ready"));
  });
});
