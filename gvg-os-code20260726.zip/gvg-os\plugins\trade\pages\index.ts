﻿import { getOverview } from "../services";
import { TRADE_MODULES } from "../modules";

/** Trade page loaders */

export async function TradeHomePage() {
  const overview = await getOverview();
  return {
    title: "Trade",
    modules: TRADE_MODULES,
    ...overview,
  };
}

export async function PoListPage() {
  return { title: "PO", purchaseOrders: [] as unknown[] };
}

export async function PoDetailPage(id: string) {
  return { title: "PO", poId: id, purchaseOrder: null };
}

export async function ShipmentListPage() {
  return { title: "Shipment", shipments: [] as unknown[] };
}

export async function ShipmentDetailPage(id: string) {
  return { title: "Shipment", shipmentId: id, shipment: null };
}

export async function CustomsListPage() {
  return { title: "Customs", filings: [] as unknown[] };
}

export async function CustomsDetailPage(id: string) {
  return { title: "Customs", customsId: id, filing: null };
}

export async function InvoiceListPage() {
  return { title: "Invoice", invoices: [] as unknown[] };
}

export async function InvoiceDetailPage(id: string) {
  return { title: "Invoice", invoiceId: id, invoice: null };
}

export async function PackingListListPage() {
  return { title: "Packing List", packingLists: [] as unknown[] };
}

export async function PackingListDetailPage(id: string) {
  return { title: "Packing List", packingListId: id, packingList: null };
}

export async function TrackingBoardPage() {
  return { title: "Tracking", milestones: [] as unknown[] };
}

export async function TrackingDetailPage(id: string) {
  return { title: "Tracking", trackingId: id, tracking: null };
}

export async function DocumentVaultPage() {
  return { title: "Documents", documents: [] as unknown[] };
}

export async function DocumentDetailPage(id: string) {
  return { title: "Document", documentId: id, document: null };
}

/** @deprecated */
export async function HomePage() {
  return TradeHomePage();
}
