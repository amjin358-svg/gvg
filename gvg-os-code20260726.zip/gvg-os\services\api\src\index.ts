/** @gvg/api service entry */
console.log("[@gvg/api] ready");
