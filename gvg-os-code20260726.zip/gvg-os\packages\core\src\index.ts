﻿/**
 * @gvg/core — GVG OS core domain
 *
 * packages/core/
 * ├── auth
 * ├── tenant
 * ├── workspace
 * ├── navigation
 * ├── permission
 * ├── featureFlag
 * ├── audit
 * └── notification
 */

export { BRAND } from "./brand";
export type { BrandInfo } from "./brand";

export { USER_ROLES, ROLE_LABELS } from "./roles";
export type { UserRole, OrganizationId, UserId, SessionUser } from "./roles";

export type {
  ProductCategory,
  TradeService,
  OrderStatus,
  RfqStatus,
  QuoteStatus,
  Brand,
  Category,
  Product,
  Rfq,
  Quote,
  Order,
  Warehouse,
  LogisticsShipment,
  NavItem,
  PlatformModule,
} from "./domain";

export { slugify, formatMoney, assertNever } from "./utils";

export {
  login,
  logout,
  createSession,
  readSession,
  writeSession,
  clearSession,
  setSessionWorkspace,
  setPluginsLoaded,
  isAuthenticated,
  hasWorkspace,
  hasPluginsLoaded,
  resolveAuthPath,
  AUTH_STORAGE_KEY,
  WORKSPACE_STORAGE_KEY,
} from "./auth";
export type { AuthUser, AuthSession } from "./auth";

export {
  setTenantContext,
  getTenantContext,
  requireTenant,
  createTenant,
} from "./tenant";
export type { Tenant, TenantPlan, TenantContext } from "./tenant";

export {
  setCurrentWorkspace,
  getCurrentWorkspaceId,
  createWorkspace,
  listWorkspaces,
  getWorkspace,
  getCurrentWorkspace,
  selectWorkspace,
  WORKSPACE_OPTIONS,
} from "./workspace";
export type { Workspace, WorkspaceKind, WorkspaceMembership } from "./workspace";

export {
  getNav,
  getNavForRole,
  defineNav,
  WORKSPACE_NAV,
  getWorkspaceNav,
  getEnabledWorkspaceNav,
  getEnabledMenuItems,
  getWorkspaceModule,
  MENU_ITEMS,
  menu,
  defaultMenu,
} from "./navigation";
export type {
  AppShell,
  NavTree,
  WorkspaceModuleId,
  WorkspaceNavItem,
  MenuItem,
} from "./navigation";

export { permissionsFor, can, assertCan } from "./permission";
export type { Permission } from "./permission";

export {
  defineFlag,
  defineFlags,
  isEnabled,
  setFlag,
  listFlags,
  clearFlags,
  MODULE_FLAGS,
  seedModuleFlags,
  isModuleEnabled,
  listEnabledModules,
  listDisabledModules,
} from "./featureFlag";
export type { FeatureFlag, ModuleFlagKey } from "./featureFlag";

export {
  AuditLog,
  recordAudit,
  listAudit,
  clearAudit,
  createAuditEntry,
} from "./audit";
export type {
  AuditAction,
  AuditActor,
  AuditEntry,
} from "./audit";

export {
  NotificationService,
  sendNotification,
  listNotifications,
  markNotificationRead,
  clearNotifications,
  createNotification,
} from "./notification";
export type {
  Notification,
  NotificationChannel,
  NotificationSeverity,
  NotificationStatus,
} from "./notification";

export {
  GvgError,
  badRequest,
  unauthorized,
  forbidden,
  notFound,
  conflict,
  validationError,
  internalError,
  isGvgError,
} from "./errors";
export type { ErrorCode } from "./errors";

/** Kernel re-exports for convenience */
export {
  createApp,
  getConfig,
  setConfig,
  resetConfig,
  definePlugin,
  createGVGPlugin,
  createPluginHost,
  createDomainEvent,
  on,
  off,
  emit,
  register,
  resolve,
  list,
  createLogger,
  logger,
} from "@gvg/kernel";

export const name = "@gvg/core";
export const version = "0.1.0";
